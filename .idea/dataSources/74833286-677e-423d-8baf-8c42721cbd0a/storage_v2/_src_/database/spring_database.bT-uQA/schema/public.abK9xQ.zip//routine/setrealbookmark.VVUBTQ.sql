CREATE FUNCTION setrealbookmark()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  _book_id integer := NEW.book_id;
BEGIN

  UPDATE spring_database.public.books SET mark = getcommonbookmark(_book_id)
  WHERE books.book_id = _book_id;

  RETURN NULL ;
END
$$;

