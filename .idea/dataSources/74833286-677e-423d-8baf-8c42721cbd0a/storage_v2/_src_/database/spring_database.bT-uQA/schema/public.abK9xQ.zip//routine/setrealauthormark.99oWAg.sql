CREATE FUNCTION setrealauthormark()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  _author_id integer := NEW.author_id;
BEGIN

  UPDATE spring_database.public.authors SET mark = getCommonAuthorMark(_author_id)
  WHERE authors.author_id = _author_id;

  RETURN NULL;
END
$$;

