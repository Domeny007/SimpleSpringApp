create function correctrealbookmark() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
  _book_id integer := OLD.book_id;
BEGIN

  UPDATE spring_database.public.books SET mark = getCommonBookMark(_book_id)
  WHERE books.book_id = _book_id;

  RETURN NULL;
END
$$;
