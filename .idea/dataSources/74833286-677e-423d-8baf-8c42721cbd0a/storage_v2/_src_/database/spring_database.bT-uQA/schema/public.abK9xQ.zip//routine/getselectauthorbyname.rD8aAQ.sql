create function getselectauthorbyname(text, text, integer) returns SETOF authors
LANGUAGE SQL
AS $$
SELECT *
FROM authors
WHERE (surname ~* ('(' || $2 || '.*|' || $1 || '.*)')) OR (name ~* ('(' || $1 || '.*|' || $2 || '.*)'))
ORDER BY name DESC,surname DESC LIMIT 5 OFFSET $3*5 ;
$$;
