CREATE FUNCTION getselectgenrebyname(text)
  RETURNS SETOF genres
LANGUAGE SQL
AS $$
SELECT *
FROM genres
WHERE LOWER(name) SIMILAR TO $1 || '%'
ORDER BY name DESC LIMIT 10 ;
$$;

