create function getselectgenrebyname(text) returns SETOF genres
LANGUAGE SQL
AS $$
SELECT *
FROM genres
WHERE LOWER(name) SIMILAR TO $1 || '%'
ORDER BY name DESC LIMIT 10 ;
$$;
